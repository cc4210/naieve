# Research digest

Weekday email digest, split out of the NAI:Eve (`naieve`) repo.

- `GET /api/digest/generate` builds the digest with the Anthropic API.
- `GET /api/cron/digest` (run by Vercel Cron, weekdays 17:00 UTC) calls the generator and emails the result with Resend.
- `src/emails/digest-template.ts` renders the email HTML.

## Setup

```bash
npm install
cp .env.example .env.local   # fill in the values
npm run dev
```

Deploy as its own Vercel project and set the same variables there. `CRON_SECRET` must match the secret Vercel Cron sends.

Before it can send: change the `from:` address in `src/app/api/cron/digest/route.ts` to one on a domain verified in Resend.
